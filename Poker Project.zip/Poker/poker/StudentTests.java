package poker;

import static org.junit.Assert.*;
import org.junit.Test;

public class StudentTests {

	@Test
	public void testHasPair() {
		Card[] cards = new Card[5];
		cards[0] = new Card(7, 0);
		cards[1] = new Card(5, 1);
		cards[2] = new Card(2, 3);
		cards[3] = new Card(7, 3);
		cards[4] = new Card(7, 3);
		
		assertTrue(PokerHandEvaluator.hasPair(cards));
	}
	
	@Test
	public void testHasTwoPair() {
		Card[] cards = new Card[5];
		cards[0] = new Card(13, 0);
		cards[1] = new Card(13, 1);
		cards[2] = new Card(13, 2);
		cards[3] = new Card(1, 0);
		cards[4] = new Card(1, 3);
		
		assertTrue(PokerHandEvaluator.hasTwoPair(cards));
	}
	
	@Test
	public void testHasThreeOfAKind() {
		Card[] cards = new Card[5];
		cards[0] = new Card(10, 2);
		cards[1] = new Card(10, 0);
		cards[2] = new Card(5, 0);
		cards[3] = new Card(4, 3);
		cards[4] = new Card(10, 1);
		
		assertTrue(PokerHandEvaluator.hasThreeOfAKind(cards));
	}
	
	@Test
	public void testHasStraight() {
		Card[] cards = new Card[5];
		cards[0] = new Card(10, 0);
		cards[1] = new Card(11, 2);
		cards[2] = new Card(12, 1);
		cards[3] = new Card(13, 0);
		cards[4] = new Card(1, 3);
		
		assertTrue(PokerHandEvaluator.hasStraight(cards));
	}
	
	@Test
	public void testHasFlush() {
		Card[] cards = new Card[5];
		cards[0] = new Card(3, 3);
		cards[1] = new Card(6, 3);
		cards[2] = new Card(12, 3);
		cards[3] = new Card(9, 3);
		cards[4] = new Card(1, 3);
		
		assertTrue(PokerHandEvaluator.hasFlush(cards));
	}
	
	@Test
	public void testHasFullHouse() {
		Card[] cards = new Card[5];
		cards[0] = new Card(13, 0);
		cards[1] = new Card(13, 3);
		cards[2] = new Card(1, 3);
		cards[3] = new Card(2, 2);
		cards[4] = new Card(1, 1);
		
		assertFalse(PokerHandEvaluator.hasFullHouse(cards));
	}
	
	@Test
	public void testHasFourOfAKind() {
		Card[] cards = new Card[5];
		cards[0] = new Card(1, 0);
		cards[1] = new Card(1, 1);
		cards[2] = new Card(2, 1);
		cards[3] = new Card(1, 3);
		cards[4] = new Card(1, 2);
		
		assertTrue(PokerHandEvaluator.hasFourOfAKind(cards));
	}
	
	@Test
	public void testHasStraightFlush() {
		Card[] cards = new Card[5];
		cards[0] = new Card(10, 0);
		cards[1] = new Card(11, 0);
		cards[2] = new Card(12, 0);
		cards[3] = new Card(13, 0);
		cards[4] = new Card(1, 1);
		
		assertFalse(PokerHandEvaluator.hasStraightFlush(cards));
	}
	
	@Test
	
	public void testConstructors() {
		/*Deck deck = new Deck();
		Deck copy = new Deck(deck);
		
		for(int i = 0; i < copy.getNumCards(); i++) {
			System.out.println(copy.getCardAt(i).toString());
		}*/
	}
	
	@Test
	
	public void testDeckShuffle() {
		/*Deck deck = new Deck();
		deck.shuffle();
		
		for(int i = 0; i < deck.getNumCards(); i++) {
			System.out.println(deck.getCardAt(i).toString());
		}*/
	}
}