package poker;
public class PokerHandEvaluator {
	
	public static boolean hasPair(Card[] cards) {
		int counter = duplicateCounter(cards);
		
		if(counter == 2 || hasThreeOfAKind(cards) || hasFourOfAKind(cards) || hasFullHouse(cards)) {
			return true;
		}
		return false;
	}
	
	public static boolean hasTwoPair(Card[] cards) {
		int counter = duplicateCounter(cards);
		
		if(hasFullHouse(cards)) {
			return true;
		} else if(hasFourOfAKind(cards)) {
			return false;
		} else if(counter == 4) {
			return true;
		}
		return false;
	}
	
	public static boolean hasThreeOfAKind(Card[] cards) {
		int counter = duplicateCounter(cards);
		
		if(counter == 6 || hasFourOfAKind(cards) || hasFullHouse(cards)) {
			return true;
		} else {
			return false;
		}
	}
	
	public static boolean hasStraight(Card [] cards) {	
		int value = 13;
		int cardsInStraight = 1;
		boolean hasAce = false;
		boolean hasTen = false;
		
		// Check for the case that the ace is used at the end
		for(int i = 0; i < cards.length; i++) {
			if(1 == cards[i].getValue()) {
				hasAce = true;
			} else if(10 == cards[i].getValue()) {
				hasTen = true;
			}
		}
		
		// Identifying the lowest value
		for(int i = 0; i < cards.length; i++) {
			if(cards[i].getValue() < value) {
				value = cards[i].getValue();
			}
		}
		
		if(hasAce && hasTen) {
			value = 10;
		}

		// Checking for cards with 1 value higher consecutively
		for(int i = 0; i < cards.length; i++) {
			for(int j = 0; j < cards.length; j++) {
				if(i != j && value + 1 == cards[j].getValue()) { 
					cardsInStraight++;
					value++;
				}
			}
		}
		System.out.print(cardsInStraight);
		if(cardsInStraight == 5) {
			return true;
		} else if(cardsInStraight == 4 && hasAce && hasTen) {
			return true;
		}
		return false;
	}
	
	public static boolean hasFlush(Card[] cards) {
		return cards[0].getSuit() == cards[1].getSuit() && cards[1].getSuit() == cards[2].getSuit() && cards[2].getSuit() == cards[3].getSuit() 
				&& cards[3].getSuit() == cards[4].getSuit();
	}
	
	public static boolean hasFullHouse(Card[] cards) {
		int counter = duplicateCounter(cards);
		
		if(counter == 8) {
			return true;
		}
		return false;
	}
	
	public static boolean hasFourOfAKind(Card[] cards) {
		int counter = 1;
		
		// Full house creates problems with the counter
		if(hasFullHouse(cards)) {
			return false;
		}
		
		// Comparing Cards
		for(int i = 0; i < cards.length - 1; i++) {
			if(cards[i].getValue() == cards[i + 1].getValue()) {
				counter++;
			}
		}
		
		if(cards[0].getValue() == cards[cards.length - 1].getValue()) {
			counter++;
		}
		if(counter == 4) {
			return true;
		}
		return false;
	}
	
	public static boolean hasStraightFlush(Card[] cards) {
		if(hasFlush(cards) && hasStraight(cards)) {
			return true;
		}
		return false;
	}
	
	public static int duplicateCounter(Card[] cards) { // Find a way to return the value
		int counter = 0;
		
		// Compares every card to each other
		for(int i = 0; i < cards.length; i++) {
			for(int j = 0; j < cards.length; j++) {
				if(i != j && cards[i].getValue() == cards[j].getValue()) { 
					counter++;
				}
			}
		}
		return counter;
	}
}

