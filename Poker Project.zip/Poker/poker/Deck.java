package poker;

public class Deck {

	private Card[] cards;

	public Deck() {
		cards = new Card[52];
		int suite = 0;
		int value = 1;
		
		for(int i = 0; i < cards.length; i++) {
			// Making the values repeat while changing the suite
			if(value > 13) {
				value = 1;
				suite++;
			}
			
			// Filling out the cards array
			cards[i] = new Card(value, suite);
			value++;
		}
	}

	public Deck(Deck other) {
		this.cards = new Card[other.cards.length];
		
		for(int i = 0; i < other.cards.length; i++) {
			this.cards[i] = other.cards[i];
		}
	}

	public Card getCardAt(int position) {
		return cards[position];
	}

	public int getNumCards() {
		return cards.length;
	}

	public void shuffle() {
		Card[] topPacket = new Card[(cards.length / 2) + cards.length % 2];
		Card[] bottomPacket = new Card[(cards.length / 2)];
		
		// Filling out two array representing the top and bottom pocket
		for(int i = 0; i < topPacket.length; i++) {
			topPacket[i] = cards[i];
		}
		
		int counter = (cards.length / 2) + cards.length % 2;
		for(int j = 0; j < bottomPacket.length; j++) {
			bottomPacket[j] = cards[counter];
			counter++;
		}
		
		// Finishing the shuffle
		int topFilter = 0;
		int bottomFilter = 0;
		for(int k = 0; k < cards.length; k++) {
			if(k % 2 == 0) {
				cards[k] = topPacket[topFilter];
				topFilter++;
			} else {
				cards[k] = bottomPacket[bottomFilter];
				bottomFilter++;
			}
		}
	}

	public void cut(int position) {
		Card[] temp = new Card[cards.length];
		int counter = 0;
		
		// Making a shallow copy for temp
		for(int i = 0; i < cards.length; i++) {
			temp[i] = cards[i];
		}
		
		// Dealing with the top portion
		for(int j = 0; j < cards.length - position; j++) {
			cards[j] = temp[position + j];
		}
			
		// Dealing with the bottom portion
		for(int k = cards.length - position; k < cards.length; k++) {
			cards[k] = temp[counter];
			counter++;
		}
	}

	public Card[] deal(int numCards) {
		Card[] smaller = new Card[cards.length - numCards];
		Card[] output = new Card[numCards];
		
		// Changing the original deck
		for(int i = 0; i < smaller.length; i++) {
			smaller[i] = cards[numCards + i];
		}
		
		// Filling the output array
		for(int j = 0; j < numCards; j++) {
			output[j] = cards[j];
		}
		cards = smaller;
		
		return output;
	}
		
}
